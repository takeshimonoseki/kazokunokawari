import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import Database from "better-sqlite3";
import { GoogleSpreadsheet } from "google-spreadsheet";
import { JWT } from "google-auth-library";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Database
const db = new Database("database.sqlite");
db.exec(`
  CREATE TABLE IF NOT EXISTS staff (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    role TEXT,
    bio TEXT,
    image_url TEXT,
    is_active INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS inquiries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT NOT NULL, -- 'customer' or 'recruitment'
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT NOT NULL,
    postal_code TEXT,
    address TEXT,
    message TEXT,
    status TEXT DEFAULT 'new',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

async function startServer() {
  const app = express();
  app.use(express.json());
  const PORT = 3000;

  // --- Spreadsheet Integration Helper ---
  const syncToSpreadsheet = async (data: any) => {
    try {
      if (!process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL || !process.env.GOOGLE_PRIVATE_KEY || !process.env.GOOGLE_SHEET_ID) {
        console.log("Spreadsheet sync skipped: Missing credentials in .env");
        return;
      }

      const serviceAccountAuth = new JWT({
        email: process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL,
        key: process.env.GOOGLE_PRIVATE_KEY.replace(/\\n/g, "\n"),
        scopes: ["https://www.googleapis.com/auth/spreadsheets"],
      });

      const doc = new GoogleSpreadsheet(process.env.GOOGLE_SHEET_ID, serviceAccountAuth);
      await doc.loadInfo();
      const sheet = doc.sheetsByIndex[0];
      await sheet.addRow(data);
      console.log("Synced to Google Sheets successfully");
    } catch (error) {
      console.error("Spreadsheet sync error:", error);
    }
  };

  // --- API Routes ---

  // Get active staff for the homepage
  app.get("/api/staff", (req, res) => {
    const staff = db.prepare("SELECT * FROM staff WHERE is_active = 1").all();
    res.json(staff);
  });

  // Handle customer inquiries
  app.post("/api/inquiry", async (req, res) => {
    const { name, email, phone, postal_code, address, message } = req.body;
    try {
      const stmt = db.prepare("INSERT INTO inquiries (type, name, email, phone, postal_code, address, message) VALUES (?, ?, ?, ?, ?, ?, ?)");
      stmt.run("customer", name, email, phone, postal_code, address, message);
      
      // Automation: Sync to Spreadsheet
      await syncToSpreadsheet({
        Timestamp: new Date().toISOString(),
        Type: "Customer Inquiry",
        Name: name,
        Email: email,
        Phone: phone,
        Address: `[${postal_code}] ${address}`,
        Message: message
      });

      res.json({ success: true, message: "お問い合わせを受け付けました。" });
    } catch (error) {
      res.status(500).json({ success: false, error: "送信に失敗しました。" });
    }
  });

  // Handle staff recruitment applications
  app.post("/api/apply", async (req, res) => {
    const { name, email, phone, postal_code, address, message } = req.body;
    try {
      const stmt = db.prepare("INSERT INTO inquiries (type, name, email, phone, postal_code, address, message) VALUES (?, ?, ?, ?, ?, ?, ?)");
      stmt.run("recruitment", name, email, phone, postal_code, address, message);

      // Automation: Sync to Spreadsheet
      await syncToSpreadsheet({
        Timestamp: new Date().toISOString(),
        Type: "Staff Application",
        Name: name,
        Email: email,
        Phone: phone,
        Address: `[${postal_code}] ${address}`,
        Message: message
      });

      res.json({ success: true, message: "応募を受け付けました。担当者よりご連絡いたします。" });
    } catch (error) {
      res.status(500).json({ success: false, error: "送信に失敗しました。" });
    }
  });

  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
