document.addEventListener('DOMContentLoaded', () => {
  // スムーズスクロール (固定ヘッダーの高さ考慮)
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      const targetId = this.getAttribute('href');
      if (targetId === '#') return;
      
      const targetElement = document.querySelector(targetId);
      if (targetElement) {
        e.preventDefault();
        const headerHeight = 64; // h-16 = 64px
        const elementPosition = targetElement.getBoundingClientRect().top;
        const offsetPosition = elementPosition + window.pageYOffset - headerHeight;
  
        window.scrollTo({
          top: offsetPosition,
          behavior: 'smooth'
        });
      }
    });
  });

  // 料金シミュレーターのロジック
  const simItems = document.querySelectorAll('input[name="sim-item"]');
  const simDistance = document.getElementById('sim-distance');
  const simEmergencies = document.querySelectorAll('input[name="sim-emergency"]');
  const simWait = document.getElementById('sim-wait');
  const simStops = document.getElementById('sim-stops');
  const simKey = document.getElementById('sim-key');
  const simReport = document.getElementById('sim-report');
  const simTotal = document.getElementById('sim-total');
  const simBreakdown = document.getElementById('sim-breakdown');
  const simPlanDisplay = document.getElementById('sim-plan-display');
  const simPlanName = document.getElementById('sim-plan-name');
  const simPlanPrice = document.getElementById('sim-plan-price');

  // 定数
  const PLAN_PRICES = {
    S: { name: 'Sプラン（1項目）', price: 11000 },
    M: { name: 'Mプラン（2項目）', price: 14500 },
    L: { name: 'Lプラン（3項目以上）', price: 22000 }
  };
  const KM_RATE = 50;
  const WAIT_10MIN_RATE = 700;
  const STOP_FEE = 2000;
  const KEY_FEE = 3500;
  const REPORT_PLUS_FEE = 3500;

  function calculateTotal() {
    if (!simTotal) return;
    
    let total = 0;
    const breakdown = [];

    // 1. メニュー（項目数）
    let selectedItemCount = 0;
    const selectedItemNames = [];
    simItems.forEach(checkbox => {
      if (checkbox.checked) {
        selectedItemCount++;
        selectedItemNames.push(checkbox.value);
      }
    });

    let plan = null;
    if (selectedItemCount === 0) {
      simPlanDisplay.classList.add('hidden');
    } else {
      simPlanDisplay.classList.remove('hidden');
      if (selectedItemCount === 1) plan = PLAN_PRICES.S;
      else if (selectedItemCount === 2) plan = PLAN_PRICES.M;
      else plan = PLAN_PRICES.L;

      simPlanName.textContent = plan.name;
      simPlanPrice.textContent = `${plan.price.toLocaleString()}円`;
      total += plan.price;
      breakdown.push(`<li>基本料金（${plan.name}）: ${plan.price.toLocaleString()}円</li>`);
      breakdown.push(`<li class="pl-4 text-xs text-slate-500">選択項目：${selectedItemNames.join('、')}</li>`);
    }

    // 2. 距離
    const distance = parseInt(simDistance?.value) || 0;
    const distancePrice = distance * KM_RATE;
    total += distancePrice;
    breakdown.push(`<li>出張費（往復${distance}km）: ${distancePrice.toLocaleString()}円</li>`);

    // 3. 緊急・時間帯
    let emergencyPrice = 0;
    let emergencyName = '';
    simEmergencies.forEach(radio => {
      if (radio.checked) {
        emergencyPrice = parseInt(radio.value) || 0;
        emergencyName = radio.nextElementSibling.textContent.trim();
      }
    });
    if (emergencyPrice > 0) {
      total += emergencyPrice;
      breakdown.push(`<li>緊急・時間帯料金（${emergencyName}）: ${emergencyPrice.toLocaleString()}円</li>`);
    }

    // 4. オプション
    const waitMins = parseInt(simWait?.value) || 0;
    if (waitMins > 0) {
      const waitUnits = Math.ceil(waitMins / 10);
      const waitPrice = waitUnits * WAIT_10MIN_RATE;
      total += waitPrice;
      breakdown.push(`<li>待機料金（${waitMins}分）: ${waitPrice.toLocaleString()}円</li>`);
    }

    const stops = parseInt(simStops?.value) || 0;
    if (stops > 0) {
      const stopsPrice = stops * STOP_FEE;
      total += stopsPrice;
      breakdown.push(`<li>追加立ち寄り（${stops}箇所）: ${stopsPrice.toLocaleString()}円</li>`);
    }

    // カンマ区切りでアニメーション風に表示更新
    simTotal.style.opacity = 0;
    setTimeout(() => {
      simTotal.textContent = total.toLocaleString();
      simTotal.style.opacity = 1;
    }, 200);

    // 内訳の更新
    if (simBreakdown) {
      if (selectedItemCount === 0) {
        simBreakdown.innerHTML = '<li class="text-red-500">※メニューを選択してください</li>';
      } else {
        simBreakdown.innerHTML = breakdown.join('');
      }
    }

    // フォームへの値の引き継ぎ用データ保存
    window.simulatorData = {
      plan: plan ? plan.name : '',
      selectedItems: selectedItemNames,
      totalKm: distance,
      urgency: emergencyName,
      options: {
        waitMins: waitMins,
        stops: stops
      },
      total: total,
      breakdownJSON: JSON.stringify(breakdown.map(b => b.replace(/<[^>]*>?/gm, '')))
    };
  }

  // イベントリスナーの登録
  if (simItems.length > 0) {
    simItems.forEach(el => el.addEventListener('change', calculateTotal));
    if (simDistance) simDistance.addEventListener('input', calculateTotal);
    simEmergencies.forEach(el => el.addEventListener('change', calculateTotal));
    if (simWait) simWait.addEventListener('input', calculateTotal);
    if (simStops) simStops.addEventListener('input', calculateTotal);
    
    // 初期計算
    calculateTotal();
  }

  // 「この内容で依頼へ進む」ボタンの処理
  const btnApply = document.getElementById('btn-apply-simulator');
  if (btnApply) {
    btnApply.addEventListener('click', (e) => {
      if (!window.simulatorData || window.simulatorData.selectedItems.length === 0) {
        e.preventDefault();
        alert('ご希望のメニューを選択してください。');
        return;
      }
      
      // フォームの各フィールドに値をセット
      const form = document.getElementById('form-request');
      if (form) {
        // メニューのセット
        const selectedItemsCheckboxes = form.querySelectorAll('input[name="selectedItems"]');
        selectedItemsCheckboxes.forEach(cb => {
          if (window.simulatorData.selectedItems.includes(cb.value)) {
            cb.checked = true;
          } else {
            cb.checked = false;
          }
          cb.style.pointerEvents = 'none';
          cb.closest('label').classList.add('bg-slate-100', 'opacity-70');
          cb.closest('label').style.pointerEvents = 'none';
        });

        // プランの選択
        const packTypeSelect = form.querySelector('select[name="plan"]');
        if (packTypeSelect && window.simulatorData.plan) {
          const planName = window.simulatorData.plan.substring(0, 2); // "Sプ", "Mプ", "Lプ"
          Array.from(packTypeSelect.options).forEach(opt => {
            if (opt.value.startsWith(planName)) {
              packTypeSelect.value = opt.value;
            }
          });
          packTypeSelect.style.pointerEvents = 'none';
          packTypeSelect.classList.add('bg-slate-100', 'opacity-70');
        }

        // 距離のセット
        const distanceInput = form.querySelector('input[name="distance"]');
        if (distanceInput) {
          distanceInput.value = window.simulatorData.totalKm;
          distanceInput.readOnly = true;
          distanceInput.classList.add('bg-slate-100', 'opacity-70');
        }

        // 緊急度のセット
        const urgencySelect = form.querySelector('select[name="urgency"]');
        if (urgencySelect && window.simulatorData.urgency) {
          const urgencyName = window.simulatorData.urgency.split(' ')[0]; // "通常（3日以降）" -> "通常"
          Array.from(urgencySelect.options).forEach(opt => {
            if (opt.value.startsWith(urgencyName)) {
              urgencySelect.value = opt.value;
            }
          });
          urgencySelect.style.pointerEvents = 'none';
          urgencySelect.classList.add('bg-slate-100', 'opacity-70');
        }

        // オプションのセット
        const optionsCheckboxes = form.querySelectorAll('input[name="options"]');
        optionsCheckboxes.forEach(cb => {
          if (cb.value === '待機時間あり' && window.simulatorData.options.waitMins > 0) cb.checked = true;
          if (cb.value === '追加立ち寄りあり' && window.simulatorData.options.stops > 0) cb.checked = true;
          
          cb.style.pointerEvents = 'none';
          cb.closest('label').classList.add('bg-slate-100', 'opacity-70');
          cb.closest('label').style.pointerEvents = 'none';
        });

        // シミュレーター反映メッセージの表示
        let simMessage = document.getElementById('sim-reflected-msg');
        if (!simMessage) {
          simMessage = document.createElement('div');
          simMessage.id = 'sim-reflected-msg';
          simMessage.className = 'bg-orange-100 text-orange-800 p-4 rounded-xl mb-6 font-bold text-sm border border-orange-200';
          simMessage.innerHTML = '※シミュレーターの結果が反映されています。プランやオプションを変更する場合は、<a href="#simulator" class="underline text-orange-600">シミュレーター</a>を再操作してください。';
          form.insertBefore(simMessage, form.firstChild);
        }

        // 隠しフィールドに詳細データをセット
        let hiddenInput = form.querySelector('input[name="simulatorData"]');
        if (!hiddenInput) {
          hiddenInput = document.createElement('input');
          hiddenInput.type = 'hidden';
          hiddenInput.name = 'simulatorData';
          form.appendChild(hiddenInput);
        }
        hiddenInput.value = JSON.stringify(window.simulatorData);
      }
    });
  }
});
