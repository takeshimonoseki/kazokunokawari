// GAS WebApp URL (デプロイ後にここを書き換える)
const GAS_WEBAPP_URL = "YOUR_GAS_WEBAPP_URL_HERE";

document.addEventListener("DOMContentLoaded", () => {
  const loadedAt = Date.now();
  const requestForm = document.getElementById("form-request");
  const partnerForm = document.getElementById("form-partner");

  const handleFormSubmit = async (e, formElement) => {
    e.preventDefault();

    // 1. スパム対策: 3秒未満の送信は拒否
    if (Date.now() - loadedAt < 3000) {
      alert("送信が早すぎます。内容を再度確認してください。");
      return;
    }

    // 2. スパム対策: ハニーポット
    const honeypot = formElement.querySelector('input[name="website"]');
    if (honeypot && honeypot.value !== "") {
      console.log("Bot detected");
      return;
    }

    const submitBtn = formElement.querySelector('button[type="submit"]');
    const btnText = submitBtn.querySelector("span") || submitBtn;
    const originalText = btnText.textContent;

    // Disable button
    submitBtn.disabled = true;
    submitBtn.classList.add("opacity-75", "cursor-not-allowed");
    btnText.textContent = "送信中...";

    const formData = new FormData(formElement);
    const data = Object.fromEntries(formData.entries());

    // カスタムバリデーション（依頼フォームの場合）
    if (formElement.id === "form-request") {
      const selectedItems = formData.getAll("selectedItems");
      let simSelectedItemsLength = 0;
      if (data.simulatorData) {
        try {
          simSelectedItemsLength = JSON.parse(data.simulatorData).selectedItems.length;
        } catch (e) {
          console.error("Failed to parse simulatorData for validation", e);
        }
      }
      
      if (selectedItems.length === 0 && simSelectedItemsLength === 0) {
        alert("ご希望のメニューを1つ以上選択してください。");
        submitBtn.disabled = false;
        submitBtn.classList.remove("opacity-75", "cursor-not-allowed");
        btnText.textContent = originalText;
        return;
      }
    }

    // シミュレーターデータの展開
    if (data.simulatorData) {
      try {
        const simData = JSON.parse(data.simulatorData);
        // フォームで入力された値が優先されるように、存在しない場合のみセット
        if (!data.plan) data.plan = simData.plan;
        data.selectedItems = Array.isArray(simData.selectedItems) ? simData.selectedItems.join(', ') : simData.selectedItems;
        if (!data.distance) data.totalKm = simData.totalKm;
        else data.totalKm = data.distance; // フォームのdistanceをtotalKmとして扱う
        if (!data.urgency) data.urgency = simData.urgency;
        
        if (simData.options) {
          const optArr = [];
          if (simData.options.waitMins > 0) optArr.push(`待機時間(${simData.options.waitMins}分)`);
          if (simData.options.stops > 0) optArr.push(`追加立ち寄り(${simData.options.stops}箇所)`);
          if (optArr.length > 0) {
            data.options = optArr.join(", ");
          }
        }
        
        data.breakdownJSON = simData.breakdownJSON;
        delete data.simulatorData; // 送信データから削除
      } catch (e) {
        console.error("Failed to parse simulator data", e);
      }
    } else {
      // シミュレーターを通さなかった場合
      data.totalKm = data.distance || "";
    }

    // チェックボックス（複数選択）の処理
    if (formElement.id === "form-request") {
      const options = formData.getAll("options");
      if (options.length > 0 && !data.options) {
        data.options = options.join(", ");
      }
      
      const selectedItems = formData.getAll("selectedItems");
      if (selectedItems.length > 0) {
        data.selectedItems = selectedItems.join(", ");
      } else if (!data.selectedItems) {
        // もしシミュレーターデータからも取得できていなければエラーにするなどの処理も可能
        data.selectedItems = "";
      }
    }

    data.timestamp = new Date().toISOString();
    data.formType = formElement.id === "form-request" ? "request" : "partner";

    // 3. スパム対策: ペイロードサイズ上限
    if (JSON.stringify(data).length > 5000) {
      alert("入力文字数が多すぎます。");
      submitBtn.disabled = false;
      submitBtn.classList.remove("opacity-75", "cursor-not-allowed");
      btnText.textContent = originalText;
      return;
    }

    try {
      // GASへ送信 (no-corsモードでCORSエラーを回避)
      await fetch(GAS_WEBAPP_URL, {
        method: "POST",
        mode: "no-cors",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      // 送信成功としてサンクスページへ遷移
      window.location.href = "/thanks.html?type=" + data.formType;
    } catch (error) {
      console.error("Error:", error);
      alert("送信に失敗しました。通信環境をご確認の上、再度お試しください。");

      // Reset button
      submitBtn.disabled = false;
      submitBtn.classList.remove("opacity-75", "cursor-not-allowed");
      btnText.textContent = originalText;
    }
  };

  if (requestForm) {
    requestForm.addEventListener("submit", (e) =>
      handleFormSubmit(e, requestForm),
    );
  }

  if (partnerForm) {
    partnerForm.addEventListener("submit", (e) =>
      handleFormSubmit(e, partnerForm),
    );
  }
});
