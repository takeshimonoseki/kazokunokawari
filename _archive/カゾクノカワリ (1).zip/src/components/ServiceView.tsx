import React from 'react';
import { motion } from 'motion/react';
import { Heart, ShieldCheck, ShoppingCart, Trash2, MessageCircle, Phone, ArrowRight, Mail, Search, MapPin } from 'lucide-react';

export default function ServiceView() {
  const [staff, setStaff] = React.useState<any[]>([]);
  const [formData, setFormData] = React.useState({ 
    name: '', 
    email: '', 
    phone: '',
    postal_code: '',
    address: '',
    message: '' 
  });
  const [status, setStatus] = React.useState<{ type: 'success' | 'error', msg: string } | null>(null);
  const [loading, setLoading] = React.useState(false);

  React.useEffect(() => {
    fetch('/api/staff')
      .then(res => res.json())
      .then(data => setStaff(data));
  }, []);

  const handleZipLookup = async (zip: string) => {
    if (zip.length === 7) {
      try {
        const res = await fetch(`https://zipcloud.ibsnet.co.jp/api/search?zipcode=${zip}`);
        const data = await res.json();
        if (data.results) {
          const { address1, address2, address3 } = data.results[0];
          setFormData(prev => ({ ...prev, address: `${address1}${address2}${address3}` }));
        }
      } catch (err) {
        console.error("Zip lookup failed", err);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setStatus(null);

    try {
      const res = await fetch('/api/inquiry', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      if (data.success) {
        setStatus({ type: 'success', msg: data.message });
        setFormData({ name: '', email: '', phone: '', postal_code: '', address: '', message: '' });
      } else {
        throw new Error(data.error);
      }
    } catch (err) {
      setStatus({ type: 'error', msg: '送信に失敗しました。' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center justify-center overflow-hidden px-6">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://picsum.photos/seed/elderly-care/1920/1080" 
            alt="Warm elderly care" 
            className="w-full h-full object-cover opacity-20"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#f5f5f0]" />
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="relative z-10 text-center max-w-3xl"
        >
          <span className="text-sm uppercase tracking-[3px] text-[#5A5A40] font-semibold mb-4 block">
            ご家族の代わりに、心を込めて。
          </span>
          <h1 className="serif text-6xl md:text-8xl font-light mb-8 leading-tight">
            カゾクノカワリ
          </h1>
          <p className="text-lg md:text-xl text-gray-600 mb-10 leading-relaxed">
            訪問介護では対応できない「ちょっとしたお願い」を代行します。<br className="hidden md:block" />
            離れて暮らすご家族に代わって、地域の安心を支えます。
          </p>
          <button className="olive-button text-lg flex items-center gap-2 mx-auto">
            よくあるご依頼を見る <ArrowRight size={20} />
          </button>
        </motion.div>
      </section>

      {/* Services Grid */}
      <section className="py-24 px-6 max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="serif text-4xl mb-4">よくあるご依頼</h2>
          <p className="text-gray-500 italic">訪問介護の人ができない仕事を中心にサポートします</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            { icon: <Search className="text-[#5A5A40]" />, title: "お墓の様子見と清掃", desc: "定期的にお墓を訪問し、お掃除や草むしりを行います。お花のお供えも承ります。" },
            { icon: <Trash2 className="text-[#5A5A40]" />, title: "ゴミ出し・片付け", desc: "重いゴミの搬出や、お部屋の整理整頓など、生活の中の小さなお困りごとを解決します。" },
            { icon: <ShoppingCart className="text-[#5A5A40]" />, title: "お買い物代行・同行", desc: "日常の買い物代行や、病院・お散歩への同行など、移動の不安をサポートします。" },
            { icon: <Heart className="text-[#5A5A40]" />, title: "その他お任せ", desc: "電球交換、お庭の手入れ、お話し相手など、範囲内であれば何でもご相談ください。" },
          ].map((service, i) => (
            <motion.div 
              key={i}
              whileHover={{ y: -10 }}
              className="card p-10 text-center flex flex-col items-center"
            >
              <div className="w-16 h-16 bg-[#f5f5f0] rounded-full flex items-center justify-center mb-6">
                {service.icon}
              </div>
              <h3 className="serif text-2xl mb-4">{service.title}</h3>
              <p className="text-gray-600 leading-relaxed">{service.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Staff Section */}
      {staff.length > 0 && (
        <section className="py-24 px-6 bg-[#f5f5f0]">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="serif text-4xl mb-4">スタッフ紹介</h2>
              <p className="text-gray-500 italic">地域の皆様をサポートする、信頼できる仲間たちです</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {staff.map((s, i) => (
                <motion.div key={i} className="card p-6 text-center">
                  <img 
                    src={s.image_url || `https://picsum.photos/seed/${s.id}/300/400`} 
                    alt={s.name} 
                    className="pill-image w-full mb-6"
                    referrerPolicy="no-referrer"
                  />
                  <h3 className="serif text-xl font-bold mb-1">{s.name}</h3>
                  <p className="text-[#5A5A40] text-sm mb-4">{s.role}</p>
                  <p className="text-gray-600 text-sm leading-relaxed">{s.bio}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Pricing Section */}
      <section className="bg-white py-24 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="serif text-4xl mb-12">明朗な料金体系</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="border border-gray-100 rounded-[32px] p-10 bg-[#f5f5f0]/30">
              <h3 className="serif text-2xl mb-2">スポット利用</h3>
              <p className="text-gray-500 mb-6 italic">まずは一度試してみたい方に</p>
              <div className="text-4xl font-light mb-6">
                <span className="text-lg">30分</span> 1,500<span className="text-lg">円〜</span>
              </div>
              <ul className="text-left text-gray-600 space-y-3 mb-8">
                <li>・交通費一律 500円</li>
                <li>・15分単位の延長可能 (750円)</li>
                <li>・事前見積もり無料</li>
              </ul>
            </div>
            <div className="border-2 border-[#5A5A40] rounded-[32px] p-10 relative overflow-hidden">
              <div className="absolute top-0 right-0 bg-[#5A5A40] text-white px-6 py-1 text-sm rounded-bl-2xl">
                オススメ
              </div>
              <h3 className="serif text-2xl mb-2">定期見守りプラン</h3>
              <p className="text-gray-500 mb-6 italic">離れて暮らすご家族の安心のために</p>
              <div className="text-4xl font-light mb-6">
                <span className="text-lg">月額</span> 5,000<span className="text-lg">円</span>
              </div>
              <ul className="text-left text-gray-600 space-y-3 mb-8">
                <li>・週1回 30分の訪問</li>
                <li>・ご家族への写真付き報告</li>
                <li>・緊急時の優先対応</li>
              </ul>
            </div>
          </div>
          <p className="mt-12 text-gray-400 text-sm italic">
            ※上記は標準料金です。ご依頼内容や立ち寄り場所により割引・調整が適用される場合がございます。お気軽にご相談ください。
          </p>
        </div>
      </section>

      {/* Inquiry Form */}
      <section className="py-24 px-6 bg-[#f5f5f0]">
        <div className="max-w-2xl mx-auto card p-10 md:p-16">
          <h2 className="serif text-3xl text-center mb-8">お問い合わせ・お申し込み</h2>
          
          {status && (
            <div className={`mb-8 p-4 rounded-xl text-center ${status.type === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
              {status.msg}
            </div>
          )}

          <form className="space-y-6" onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">お名前 <span className="text-red-500">*</span></label>
                <input 
                  type="text" 
                  required
                  value={formData.name}
                  onChange={e => setFormData({...formData, name: e.target.value})}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-[#5A5A40] focus:border-transparent outline-none" 
                  placeholder="山田 太郎" 
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">電話番号 <span className="text-red-500">*</span></label>
                <input 
                  type="tel" 
                  required
                  value={formData.phone}
                  onChange={e => setFormData({...formData, phone: e.target.value})}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-[#5A5A40] focus:border-transparent outline-none" 
                  placeholder="090-0000-0000" 
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">メールアドレス <span className="text-red-500">*</span></label>
              <input 
                type="email" 
                required
                value={formData.email}
                onChange={e => setFormData({...formData, email: e.target.value})}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-[#5A5A40] focus:border-transparent outline-none" 
                placeholder="example@mail.com" 
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">郵便番号</label>
                <input 
                  type="text" 
                  maxLength={7}
                  value={formData.postal_code}
                  onChange={e => {
                    const val = e.target.value.replace(/\D/g, '');
                    setFormData({...formData, postal_code: val});
                    handleZipLookup(val);
                  }}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-[#5A5A40] focus:border-transparent outline-none" 
                  placeholder="1234567" 
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">住所</label>
                <input 
                  type="text" 
                  value={formData.address}
                  onChange={e => setFormData({...formData, address: e.target.value})}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-[#5A5A40] focus:border-transparent outline-none" 
                  placeholder="〇〇市〇〇区〇〇 1-2-3" 
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">ご相談内容 <span className="text-red-500">*</span></label>
              <textarea 
                required
                value={formData.message}
                onChange={e => setFormData({...formData, message: e.target.value})}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-[#5A5A40] focus:border-transparent outline-none h-32" 
                placeholder="どのようなことでお困りですか？"
              ></textarea>
            </div>
            <button 
              type="submit" 
              disabled={loading}
              className="olive-button w-full text-lg py-4 flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <Mail size={20} /> {loading ? '送信中...' : 'この内容で送信する'}
            </button>
          </form>
        </div>
      </section>

      {/* Footer / CTA */}
      <footer className="py-24 px-6 text-center">
        <h2 className="serif text-3xl mb-8">お気軽にご相談ください</h2>
        <div className="flex flex-col md:flex-row gap-4 justify-center items-center">
          <button className="olive-button flex items-center gap-2">
            <MessageCircle size={20} /> LINEで相談する
          </button>
          <button className="border border-[#5A5A40] text-[#5A5A40] rounded-full px-8 py-3 flex items-center gap-2 hover:bg-[#5A5A40] hover:text-white transition-all">
            <Phone size={20} /> 0120-XXX-XXX
          </button>
        </div>
        <p className="mt-12 text-gray-400 text-sm">© 2026 カゾクノカワリ. All rights reserved.</p>
      </footer>
    </div>
  );
}
