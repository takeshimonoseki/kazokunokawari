import React from 'react';
import { motion } from 'motion/react';
import { Users, Heart, Clock, MapPin, ArrowRight, Mail, CheckCircle2, Search, Phone } from 'lucide-react';

export default function RecruitmentView() {
  const [formData, setFormData] = React.useState({ 
    name: '', 
    email: '', 
    phone: '',
    postal_code: '',
    address: '',
    message: '' 
  });
  const [status, setStatus] = React.useState<{ type: 'success' | 'error', msg: string } | null>(null);
  const [loading, setLoading] = React.useState(false);

  const handleZipLookup = async (zip: string) => {
    if (zip.length === 7) {
      try {
        const res = await fetch(`https://zipcloud.ibsnet.co.jp/api/search?zipcode=${zip}`);
        const data = await res.json();
        if (data.results) {
          const { address1, address2, address3 } = data.results[0];
          setFormData(prev => ({ ...prev, address: `${address1}${address2}${address3}` }));
        }
      } catch (err) {
        console.error("Zip lookup failed", err);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setStatus(null);

    try {
      const res = await fetch('/api/apply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      if (data.success) {
        setStatus({ type: 'success', msg: data.message });
        setFormData({ name: '', email: '', phone: '', postal_code: '', address: '', message: '' });
      } else {
        throw new Error(data.error);
      }
    } catch (err) {
      setStatus({ type: 'error', msg: '送信に失敗しました。時間をおいて再度お試しください。' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[70vh] flex items-center justify-center overflow-hidden px-6 bg-[#5A5A40] text-white">
        <div className="absolute inset-0 z-0 opacity-20">
          <img 
            src="https://picsum.photos/seed/community/1920/1080" 
            alt="Community support" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="relative z-10 text-center max-w-4xl"
        >
          <span className="text-sm uppercase tracking-[4px] opacity-80 mb-6 block">
            オープニングスタッフ募集中
          </span>
          <h1 className="serif text-5xl md:text-7xl font-light mb-8 leading-tight">
            あなたの「優しさ」を、<br />地域の安心に変えませんか？
          </h1>
          <p className="text-lg md:text-xl opacity-90 mb-10 leading-relaxed max-w-2xl mx-auto">
            「カゾクノカワリ」は、高齢者のちょっとしたお困りごとを解決する新しいサービスです。
            現在、共にサービスを創り上げる仲間を募集しています。
          </p>
          <a href="#apply" className="bg-white text-[#5A5A40] rounded-full px-10 py-4 text-lg font-semibold inline-flex items-center gap-2 hover:bg-opacity-90 transition-all">
            募集要項を見る <ArrowRight size={20} />
          </a>
        </motion.div>
      </section>

      {/* Why Join Us */}
      <section className="py-24 px-6 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="serif text-4xl mb-8">「カゾクノカワリ」で働く魅力</h2>
            <div className="space-y-8">
              {[
                { icon: <Clock />, title: "自由な働き方", desc: "週1回、30分からでもOK。あなたのライフスタイルに合わせて働けます。" },
                { icon: <Heart />, title: "直接届く「ありがとう」", desc: "介護保険では手の届かない部分をサポートするため、お客様から深く感謝される仕事です。" },
                { icon: <Users />, title: "未経験でも安心", desc: "特別な資格は不要です。お掃除や買い物など、普段の家事の延長で始められます。" },
              ].map((item, i) => (
                <div key={i} className="flex gap-6">
                  <div className="w-12 h-12 bg-[#5A5A40]/10 text-[#5A5A40] rounded-full flex items-center justify-center shrink-0">
                    {item.icon}
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="relative">
            <img 
              src="https://picsum.photos/seed/happy-staff/800/1000" 
              alt="Staff smiling" 
              className="pill-image w-full shadow-2xl"
              referrerPolicy="no-referrer"
            />
            <div className="absolute -bottom-8 -left-8 card p-8 max-w-xs hidden md:block">
              <p className="italic text-gray-600 mb-4">
                「定年後、何か地域に貢献したいと思って始めました。喜んでいただけるのが何よりのやりがいです。」
              </p>
              <p className="font-bold text-[#5A5A40]">— スタッフ Aさん</p>
            </div>
          </div>
        </div>
      </section>

      {/* Job Details */}
      <section id="apply" className="bg-white py-24 px-6">
        <div className="max-w-4xl mx-auto">
          <h2 className="serif text-4xl text-center mb-16">募集要項</h2>
          <div className="card overflow-hidden border border-gray-100">
            <div className="divide-y divide-gray-100">
              {[
                { label: "職種", value: "生活サポートスタッフ（カゾクノカワリ）" },
                { label: "仕事内容", value: "買い物代行、安否確認、お話し相手、ゴミ出し、庭掃除、電球交換など" },
                { label: "給与", value: "時給 1,200円 〜 1,800円（＋交通費支給）" },
                { label: "勤務地", value: "ご希望のエリア（直行直帰OK）" },
                { label: "応募資格", value: "年齢・経験不問。スマートフォンで報告ができる方。お年寄りが好きな方大歓迎。" },
              ].map((row, i) => (
                <div key={i} className="flex flex-col md:flex-row p-6 md:p-8">
                  <div className="md:w-1/3 font-bold text-[#5A5A40] mb-2 md:mb-0">{row.label}</div>
                  <div className="md:w-2/3 text-gray-600">{row.value}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-16 text-center">
            <h3 className="serif text-2xl mb-8">応募の流れ</h3>
            <div className="flex flex-col md:flex-row justify-between items-center gap-8">
              {["フォームから応募", "面談（オンライン可）", "研修・説明", "お仕事スタート"].map((step, i) => (
                <div key={i} className="flex flex-col items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-[#5A5A40] text-white flex items-center justify-center font-bold">
                    {i + 1}
                  </div>
                  <div className="font-medium">{step}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section className="py-24 px-6 bg-[#f5f5f0]">
        <div className="max-w-2xl mx-auto card p-10 md:p-16">
          <h2 className="serif text-3xl text-center mb-8">まずは話を聞いてみる</h2>
          
          {status && (
            <div className={`mb-8 p-4 rounded-xl text-center ${status.type === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
              {status.msg}
            </div>
          )}

          <form className="space-y-6" onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">お名前 <span className="text-red-500">*</span></label>
                <input 
                  type="text" 
                  required
                  value={formData.name}
                  onChange={e => setFormData({...formData, name: e.target.value})}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-[#5A5A40] focus:border-transparent outline-none" 
                  placeholder="山田 太郎" 
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">電話番号 <span className="text-red-500">*</span></label>
                <input 
                  type="tel" 
                  required
                  value={formData.phone}
                  onChange={e => setFormData({...formData, phone: e.target.value})}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-[#5A5A40] focus:border-transparent outline-none" 
                  placeholder="090-0000-0000" 
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">メールアドレス <span className="text-red-500">*</span></label>
              <input 
                type="email" 
                required
                value={formData.email}
                onChange={e => setFormData({...formData, email: e.target.value})}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-[#5A5A40] focus:border-transparent outline-none" 
                placeholder="example@mail.com" 
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">郵便番号</label>
                <input 
                  type="text" 
                  maxLength={7}
                  value={formData.postal_code}
                  onChange={e => {
                    const val = e.target.value.replace(/\D/g, '');
                    setFormData({...formData, postal_code: val});
                    handleZipLookup(val);
                  }}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-[#5A5A40] focus:border-transparent outline-none" 
                  placeholder="1234567" 
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">ご住所</label>
                <input 
                  type="text" 
                  value={formData.address}
                  onChange={e => setFormData({...formData, address: e.target.value})}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-[#5A5A40] focus:border-transparent outline-none" 
                  placeholder="〇〇市〇〇区〇〇 1-2-3" 
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">メッセージ（任意）</label>
              <textarea 
                value={formData.message}
                onChange={e => setFormData({...formData, message: e.target.value})}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-[#5A5A40] focus:border-transparent outline-none h-32" 
                placeholder="質問などあればお気軽にご記入ください"
              ></textarea>
            </div>
            <button 
              type="submit" 
              disabled={loading}
              className="olive-button w-full text-lg py-4 flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <Mail size={20} /> {loading ? '送信中...' : 'この内容で送信する'}
            </button>
          </form>
        </div>
      </section>

      <footer className="py-12 px-6 text-center text-gray-400 text-sm">
        © 2026 カゾクノカワリ 採用窓口
      </footer>
    </div>
  );
}
