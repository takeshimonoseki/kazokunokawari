import React, { useState, useEffect } from 'react';
import RecruitmentView from './components/RecruitmentView';
import ServiceView from './components/ServiceView';
import { Settings, Eye, Users } from 'lucide-react';

/**
 * App Component
 * 
 * This component handles the switching between "Recruitment Mode" and "Service Mode".
 * By default, it shows the Recruitment Mode as requested.
 */
export default function App() {
  // mode: which page is currently being viewed in the preview
  const [mode, setMode] = useState<'recruitment' | 'service'>('recruitment');
  
  // isServiceLive: simulated toggle for whether the customer service is "launched"
  const [isServiceLive, setIsServiceLive] = useState(false);
  
  // Admin toggle visibility
  const [showAdmin, setShowAdmin] = useState(true);

  // Toggle admin panel with a keyboard shortcut (Ctrl + M)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && (e.key === 'm' || e.key === 'M')) {
        e.preventDefault();
        setShowAdmin(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div className="relative min-h-screen">
      {/* 
          Admin Control Bar
          Used by the owner to toggle between recruitment focus and full service launch.
      */}
      {showAdmin && (
        <div className="fixed top-0 left-0 right-0 z-[10000] bg-[#1a1a1a] text-white px-6 py-3 shadow-2xl flex items-center justify-between border-b border-white/10">
          <div className="flex items-center gap-6">
            <div className="flex flex-col">
              <span className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">Owner Dashboard</span>
              <span className="text-xs font-bold">サイト運営管理</span>
            </div>
            
            <div className="h-8 w-px bg-white/10 mx-2" />

            <div className="flex items-center gap-3">
              <span className="text-xs text-gray-400">現在の表示:</span>
              <div className="flex bg-white/5 p-1 rounded-lg border border-white/10">
                <button 
                  onClick={() => setMode('recruitment')}
                  className={`px-4 py-1.5 rounded-md text-xs font-bold transition-all flex items-center gap-2 ${
                    mode === 'recruitment' ? 'bg-white text-black shadow-lg' : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <Users size={14} /> 採用ページ
                </button>
                <button 
                  onClick={() => setMode('service')}
                  className={`px-4 py-1.5 rounded-md text-xs font-bold transition-all flex items-center gap-2 ${
                    mode === 'service' ? 'bg-white text-black shadow-lg' : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <Eye size={14} /> お客様向け
                </button>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3">
              <span className="text-xs text-gray-400">サービス公開設定:</span>
              <button 
                onClick={() => setIsServiceLive(!isServiceLive)}
                className={`relative w-12 h-6 rounded-full transition-colors duration-300 ${isServiceLive ? 'bg-emerald-500' : 'bg-gray-600'}`}
              >
                <div className={`absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-transform duration-300 ${isServiceLive ? 'translate-x-6' : ''}`} />
              </button>
              <span className={`text-xs font-bold ${isServiceLive ? 'text-emerald-400' : 'text-gray-400'}`}>
                {isServiceLive ? '一般公開中' : '準備中 (採用のみ)'}
              </span>
            </div>

            <button 
              onClick={() => setShowAdmin(false)}
              className="p-2 hover:bg-white/10 rounded-full transition-colors text-gray-400 hover:text-white"
              title="管理バーを隠す (Ctrl + M で再表示)"
            >
              <Settings size={20} />
            </button>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className={showAdmin ? 'pt-[64px]' : ''}>
        {/* 
            Logic: If service is NOT live, we force recruitment view for the public.
            The owner can still override this via the 'mode' state in the admin bar.
        */}
        {mode === 'recruitment' ? <RecruitmentView /> : <ServiceView />}
      </div>

      {/* Re-show button if hidden */}
      {!showAdmin && (
        <button 
          onClick={() => setShowAdmin(true)}
          className="fixed top-6 right-6 z-[9999] bg-[#1a1a1a] text-white p-3 rounded-full shadow-2xl hover:scale-110 transition-all border border-white/10"
        >
          <Settings size={20} />
        </button>
      )}
    </div>
  );
}
