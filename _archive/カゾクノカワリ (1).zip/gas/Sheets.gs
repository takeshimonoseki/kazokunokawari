const Sheets = {
  getSpreadsheet: function () {
    return SpreadsheetApp.openById(Config.SHEET_ID);
  },

  saveRequest: function (data) {
    const ss = this.getSpreadsheet();
    const sheet = ss.getSheetByName("Requests");
    if (!sheet) throw new Error("Requests sheet not found");

    const id = "REQ-" + Utilities.getUuid().substring(0, 8).toUpperCase();

    sheet.appendRow([
      data.timestamp || new Date().toISOString(),
      id,
      data.plan || "",
      data.selectedItems || "",
      data.areaPref || "",
      data.areaCity || "",
      data.specificAddress || "",
      data.totalKm || "",
      data.urgency || "",
      data.options || "",
      data.breakdownJSON || "",
      data.notes || "",
      data.name || "",
      data.email || "",
      data.address || "",
      data.phone || "",
      "新規受付",
    ]);

    const subject = `【新規依頼】${data.areaPref}${data.areaCity} - ${data.plan}プラン`;
    const body = `新規依頼がありました。\nID: ${id}\nプラン: ${data.plan}\n項目: ${data.selectedItems}\n距離: ${data.totalKm ? data.totalKm + 'km' : '未入力'}\n緊急度: ${data.urgency}\nオプション: ${data.options}\nメール: ${data.email}`;

    Mail.send(subject, body);
    Line.push(subject, body);
  },

  savePartner: function (data) {
    const ss = this.getSpreadsheet();
    const sheet = ss.getSheetByName("Partners");
    if (!sheet) throw new Error("Partners sheet not found");

    const id = "PTN-" + Utilities.getUuid().substring(0, 8).toUpperCase();

    sheet.appendRow([
      data.timestamp || new Date().toISOString(),
      id,
      data.name || "",
      data.ageGroup || "",
      data.areaPref || "",
      data.license || "",
      data.availableDays || "",
      data.contactLine || "",
      data.email || "",
      "未確認（身分証待ち）",
      "", // ID_Image_URL
      "", // BankInfo
    ]);

    const subject = `【新規パートナー登録】${data.areaPref} - ${data.name}`;
    const body = `新規パートナー登録がありました。\nID: ${id}\nエリア: ${data.areaPref}\nメール: ${data.email}`;

    Mail.send(subject, body);
    Line.push(subject, body);
  },
};
